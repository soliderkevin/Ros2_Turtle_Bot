import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class TurtleMover(Node):
    def __init__(self):
        super().__init__('turtle_mover')
        self.publisher_ = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        self.timer = self.create_timer(0.5, self.timer_callback)  # 每0.5秒執行一次

    def timer_callback(self):
        msg = Twist()

        msg.linear.x = 1.0  # 設定向前的線速度
        msg.linear.y = 0.0
        msg.linear.z = 0.0

        msg.angular.x = 0.0  # 不旋轉
        msg.angular.y = 0.0
        msg.angular.z = 0.0

        self.publisher_.publish(msg)
        self.get_logger().info('Publishing: linear.x=%.2f angular.z=%.2f' % (msg.linear.x, msg.angular.z))


def main(args=None):
    rclpy.init(args=args)
    turtle_mover = TurtleMover()
    rclpy.spin(turtle_mover)
    
    turtle_mover.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
